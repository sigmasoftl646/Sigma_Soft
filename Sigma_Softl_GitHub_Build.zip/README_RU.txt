SIGMA_SOFTL v1.0 — Android project

Что есть:
- Плавающее окно поверх приложений.
- FPS-поле, которое пытается получить фактические timestamps SurfaceFlinger для слоя com.axlebolt.standoff2 через su (KernelSU).
- Если прошивка не отдаёт слой/latency, будет показано --. Это зависит от Android/прошивки/версии игры.

Сборка прямо на телефоне:
1. Установи AndroidIDE из официального источника.
2. Распакуй Sigma_Softl.zip в папку телефона.
3. Открой папку проекта в AndroidIDE и дождись синхронизации Gradle.
4. Нажми Build / Assemble Debug.
5. Установи app/build/outputs/apk/debug/app-debug.apk.
6. Открой Sigma_Softl, разреши «Поверх других приложений», нажми «Включить FPS Monitor».
7. При запросе KernelSU предоставь root-доступ приложению.

Требования:
- Android 8.0+ (API 26+)
- Интернет при первой Gradle-сборке для загрузки зависимостей/плагинов.
- KernelSU и установленный su для чтения SurfaceFlinger.

Package: com.sigmasoftl
App name: Sigma_Softl

Примечание:
Это исходный Android-проект, а не собранный APK. В этой среде Android SDK/Gradle build не запускались, поэтому APK здесь не приложен.
