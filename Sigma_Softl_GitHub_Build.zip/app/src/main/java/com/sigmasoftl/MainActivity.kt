package com.sigmasoftl

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,16,16)
        window.navigationBarColor = Color.rgb(16,16,16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(Color.rgb(13,13,16))
        }
        val title = TextView(this).apply {
            text = "SIGMA_SOFTL"
            textSize = 28f
            setTextColor(Color.rgb(255,65,65))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "VERSION 1.0  •  KERNELSU READY"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(6), 0, dp(28))
        }
        val info = TextView(this).apply {
            text = "FPS MONITOR\nПлавающий монитор поверх игры. Для чтения системной статистики попробует использовать root через su."
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(24))
        }
        val button = Button(this).apply {
            text = "ВКЛЮЧИТЬ FPS MONITOR"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(190,35,45))
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }
        val stop = Button(this).apply {
            text = "ОСТАНОВИТЬ МОНИТОР"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        val foot = TextView(this).apply {
            text = "Если поверх игры не появляется окно, разреши Sigma_Softl отображение поверх других приложений."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(24), 0, 0)
        }
        root.addView(title); root.addView(sub); root.addView(info)
        root.addView(button, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(stop, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(foot)
        setContentView(root)
    }
}
