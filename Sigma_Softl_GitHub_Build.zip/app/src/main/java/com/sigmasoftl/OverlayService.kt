package com.sigmasoftl

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.roundToInt

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var fpsText: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var expanded = true
    private val tick = object : Runnable {
        override fun run() {
            Thread {
                val result = readGameFps()
                handler.post {
                    fpsText?.text = if (result != null) "FPS  $result" else "FPS  --"
                }
            }.start()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(41, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
        handler.post(tick)
    }

    private fun notification(): Notification {
        val channel = "sigma_monitor"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channel, "Sigma FPS Monitor", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
        return Notification.Builder(this, channel)
            .setContentTitle("Sigma_Softl")
            .setContentText("FPS Monitor активен")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    private fun showOverlay() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.rgb(24, 20, 23))
        }
        val header = TextView(this).apply {
            text = "SIGMA  ×"
            textSize = 14f
            setTextColor(Color.rgb(255,75,75))
            setOnClickListener {
                expanded = !expanded
                fpsText?.visibility = if (expanded) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
        fpsText = TextView(this).apply {
            text = "FPS  --"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 0)
        }
        wrap.addView(header); wrap.addView(fpsText)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 140 }
        panel = wrap
        try { wm.addView(wrap, params) } catch (_: Exception) {}
    }

    // Reads SurfaceFlinger frame timestamps for the Standoff 2 layer via KernelSU's su.
    private fun readGameFps(): Int? {
        return try {
            val script = """
                layers=${'$'}(dumpsys SurfaceFlinger --list 2>/dev/null | grep -i 'com.axlebolt.standoff2' | head -n 1)
                [ -z "${'$'}layers" ] && exit 2
                dumpsys SurfaceFlinger --latency "${'$'}layers" 2>/dev/null
            """.trimIndent()
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", script))
            val out = BufferedReader(InputStreamReader(p.inputStream)).readLines()
            p.waitFor()
            val stamps = out.drop(1).mapNotNull { line ->
                val cols = line.trim().split(Regex("\\s+"))
                if (cols.size >= 2) cols[1].toLongOrNull()?.takeIf { it > 0L } else null
            }.distinct().sorted().takeLast(40)
            if (stamps.size < 3) return null
            val span = stamps.last() - stamps.first()
            if (span <= 0L) null else ((stamps.size - 1) * 1_000_000_000.0 / span).roundToInt().coerceIn(1, 240)
        } catch (_: Exception) { null }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
